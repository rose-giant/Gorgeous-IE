import React from "react"
import "./footer.css"

export default function Footer() {
    return (
        <footer>
           <p>Copyright &copy; 2024 MizDooni All Rights Reserved.</p>
        </footer>
    )
}